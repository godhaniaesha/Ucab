const Booking = require("../models/Booking");
const Payment = require("../models/Payment");

const getMyTransactions = async (req, res) => {
  try {
    const userId = req.user.id; // Always take from logged-in user

    // Payouts to this user (drivers/owners)
    const payouts = await Payment.find({ payoutTo: userId })
      .populate("booking", "pickup drop fare")
      .sort({ createdAt: -1 });

    // Passenger payments for this user
    const passengerBookings = await Booking.find({ passenger: userId }).select(
      "_id"
    );
    const passengerPayments = await Payment.find({
      booking: { $in: passengerBookings.map((b) => b._id) },
    })
      .populate("booking", "pickup drop fare")
      .sort({ createdAt: -1 });

    res.json({ payouts, passengerPayments });
  } catch (err) {
    console.error("getMyTransactions error:", err);
    res.status(500).json({ message: "Server error", error: err.message });
  }
};

module.exports = { getMyTransactions };
